#include <iostream>
#include <string>

int main(int argc, char* argv[]){

  for(int i = 1; i < argc; ++i){
    if(std::string(argv[i]) == "--version"){
      std::cout<<"goldilock v1.2.1 (built from abcdefg)"<<std::endl;
      return 0;
    }
  }

  return 0;
}